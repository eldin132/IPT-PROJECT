######## INSTALLATION FOR MY WEB APPLICATION ##############


STEP 1: YOU MUST IMPORT THE dominic.sql in localhost.
STEP 2: AFTER YOU UPLOADED THE FILE. THE DATABASE NAME IS "dominic" DATABASE TABLE IS "personal".
STEP 3: NOW VISIT THIS LINK: http://localhost/Dominic/Doms/main