<?php  

defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * summary
 */
class Doms extends CI_Controller
{
    /**
     * summary
     */
    function main(){

    	$data['tbl_d'] = $this->doms->getdata();
    	$this->load->view('main/index',$data);
    }

    function __construct()
    {
    	parent:: __construct();
    	$this->load->model('data','doms');
    }

    function personal(){
		$data['person'] = $this->doms->getdata();
    	$this->load->view('main/personal',$data);
    }
    function about_me(){
		$data['about'] = $this->doms->getdata();
    	$this->load->view('main/about',$data);
    }
    function skills(){
		$data['skills'] = $this->doms->getdata();
    	$this->load->view('main/skills',$data);
    }
}


?>