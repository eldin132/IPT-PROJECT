<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title><?php 

						if ($person) {
							foreach ($person as $data) {
							    echo $data->fname." ".$data->lname;
							}
						}

						?></title>
	<link href="https://fonts.googleapis.com/css2?family=Lobster&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Sansita+Swashed&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="<?php echo base_url('assets/css/style.css') ?>">
</head>
<body>

<!-- header -->
	<header>
		<div class="head">
			<a href="<?php echo base_url('Doms/main') ?>"><span>Personal Information</span></a>
		</div>
	</header>
	<!-- end of header -->


	<!-- box -->

	<div class="box">
		<div class="content">
			<center><h3>Personal Information</h3></center>
			<div class="flex">
				<div class="list" id="box1">
					<ul>
						<li><span>Name: <?php 

						if ($person) {
							foreach ($person as $data) {
							    echo $data->fname." ".$data->lname;
							}
						}

						?> </span></li>
						<li><span>Address: <?php 

						if ($person) {
							foreach ($person as $data) {
							    echo $data->address;
							}
						}

						?></span></li>
						<li><span>Gender: <?php 

						if ($person) {
							foreach ($person as $data) {
							    echo $data->gender;
							}
						}

						?></span></li>
						<!-- <li><span>Name:  Shania Plaza</span></li> -->
					</ul>
				</div>
			</div>
		</div>
	</div>
	<!-- end of box -->


	<script type="text/javascript">
		
		function about(){
			window.location.href="about.html";
		}
		function skills(){
			window.location.href="skills.html";
		}

		

	</script>
	
</body>
</html>