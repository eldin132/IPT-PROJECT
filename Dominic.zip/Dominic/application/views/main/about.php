<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title><?php 

						if ($about) {
							foreach ($about as $data) {
							    echo $data->fname." ".$data->lname;
							}
						}

						?></title>
	<link href="https://fonts.googleapis.com/css2?family=Lobster&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Sansita+Swashed&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="<?php echo base_url('assets/css/style.css') ?>">
	<link href="https://fonts.googleapis.com/css2?family=Nerko+One&display=swap" rel="stylesheet">
</head>
<body>

<!-- header -->
	<header>
		<div class="head">
			<a href="<?php echo base_url('Doms/main') ?>"><span>Personal Information</span></a>
		</div>
	</header>
	<!-- end of header -->


	<!-- box -->

	<div class="box">
		<div class="content">.
			<center><h3>About me</h3></center>
			<div class="flex">
				<p>
					<?php 	

						if ($about) {
							foreach ($about as $data) {
							    echo $data->exp;
							}
						}

					 ?>
				</p>
			</div>
		</div>
	</div>


	<!-- end of box -->
	



</body>
</html>