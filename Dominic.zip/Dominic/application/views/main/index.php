<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
	<link href="https://fonts.googleapis.com/css2?family=Lobster&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Sansita+Swashed&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="<?php echo base_url('assets/css/style.css') ?>">
</head>
<body>

<!-- header -->
	<header>
		<div class="head">
			<a href="<?php echo base_url('Doms/main') ?>"><span>Personal Information</span></a>
		</div>
	</header>
	<!-- end of header -->


	<!-- box -->

	<div class="box">
		<div class="content">
			<div class="flex">
				<button class="box1" onclick="personal()">Personal Information</button>
				<button class="box2" onclick="skills();">Skills</button>
				<button class="box3" onclick="about()">About me</button>
			</div>
		</div>
	</div>
	<!-- end of box -->


	<script type="text/javascript">
		
		function about(){
			window.location.href="<?php echo base_url('Doms/about_me') ?>";
		}
		function skills(){
			window.location.href="<?php echo base_url('Doms/skills') ?>";
		}

		function personal(){
			window.location.href="<?php echo base_url('Doms/personal') ?>";
		}

	</script>
	
</body>
</html>