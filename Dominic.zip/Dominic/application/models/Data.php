<?php  

defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * summary
 */
class Data extends CI_Model
{
    /**
     * summary
     */
    public function getdata()
    {
        $table = $this->db->table_exists('personal');
	    	if ($table) {
	    		$que = $this->db->get('personal');
	    		if ($que->num_rows() > 0) {
	    			return $que->result();
	    		}
	    		else{
	    			return false;
	    		}
	    	}
	    	else {
	    		return false;
	    	}
    }
}

?>